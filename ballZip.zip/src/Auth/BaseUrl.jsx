/* eslint-disable import/no-anonymous-default-export */
export default {
  baseurl: "https://ballpark.pythonanywhere.com/api/auth/",
  baseurlImage: "https://ballpark.pythonanywhere.com/api/userauth/",
  ResImage: "https://ballpark.pythonanywhere.com/api/userauth",
  searchprojects: "https://ballpark.pythonanywhere.com/api/userauth/search_projects/",
  CostImage: "https://ballpark.pythonanywhere.com",
};

