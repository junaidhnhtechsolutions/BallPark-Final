export default function Footer() {
  return <div>
    
  </div>;
}
