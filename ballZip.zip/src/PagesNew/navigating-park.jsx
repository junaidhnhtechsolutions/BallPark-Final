import Template from "../layout/template";
import NavDescription from "../components/navigating-park/description";

export default function NavPark() {
  return (
    <div className="  example ">
      <Template>
        <NavDescription />
      </Template>
    </div>
  );
}
