import ContactForm from "../components/contact-us/ContactForm";
import Template from "../layout/template";

const Contactus = () => {
  return (
    <Template>
      <ContactForm />
    </Template>
  );
};

export default Contactus;
